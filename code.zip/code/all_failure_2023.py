import pandas as pd

# 读取四个csv文件
Q1 = pd.read_csv('../datasets/failure_disk_detail_2023/failure_disks_detail_Q1.csv')
Q2 = pd.read_csv('../datasets/failure_disk_detail_2023/failure_disks_detail_Q2.csv')
Q3 = pd.read_csv('../datasets/failure_disk_detail_2023/failure_disks_detail_Q3.csv')
Q4 = pd.read_csv('../datasets/failure_disk_detail_2023/failure_disks_detail_Q4.csv')

# 合并四个DataFrame
all_data = pd.concat([Q1, Q2, Q3, Q4])

# 保存合并后的csv文件
all_data.to_csv('../datasets/failure_disks_detail_2023.csv', index=False)
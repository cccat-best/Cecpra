import tsfresh as tsf
import pandas as pd
import numpy as np

path = 'datasets/Dropna_all_data.csv'
myDf = pd.read_csv(path)

def myTs(colName, l):
    global myDf
    df = myDf
    r = l + 6
    df = df.loc[l:r, [colName]]
    df = df.reset_index(drop=True)
    ts = pd.Series(df[colName])
    return ts

def myCe(ts):
    ce = tsf.feature_extraction.feature_calculators.cid_ce(ts, True)
    return ce

def myCf(ce1, ce2):
    cf = max(ce1, ce2) / min(ce1, ce2)
    return cf

def myEd(ts1, ts2):
    sum = 0
    for i in range(7):
        sum += np.square(ts1[i] - ts2[i])
    ed = np.sqrt(sum)
    return ed

def myCid(colName, l1, l2):
    ts1 = myTs(colName, l1)
    ts2 = myTs(colName, l2)
    ce1 = myCe(ts1)
    ce2 = myCe(ts2)
    cf = myCf(ce1, ce2)
    ed = myEd(ts1, ts2)
    cid = ed * cf
    return cid

cid1 = myCid('smart_1_normalized', 0, 1)
print(cid1)
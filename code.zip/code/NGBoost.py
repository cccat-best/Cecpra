import pandas as pd
from sklearn.metrics import accuracy_score, recall_score, confusion_matrix, roc_auc_score, f1_score
from sklearn.model_selection import train_test_split
import xgboost as xgb
import matplotlib.pyplot as plt

#读文件
df=pd.read_csv('datasets/drop_80/AbsCid_filled_80.csv')
data = df.values

X_train, X_test, y_train, y_test = train_test_split(data[:,5:], data[:,4], test_size=0.2, random_state=42, stratify=data[:,4])

y_train = y_train.astype('int')
y_test = y_test.astype('int')

import ngboost
from ngboost import NGBClassifier
from ngboost.learners import default_tree_learner
from ngboost.distns import k_categorical,Normal,Bernoulli
from ngboost.scores import LogScore
params={
    'Dist':k_categorical(2), # 预测值y的分布，取值k_categorical, Bernoulli,Normal,Exponential等
    'Score':LogScore, # 损失函数，取值LogScore, CRPScore
    'Base':default_tree_learner, # 基学习器、类似于子树，取值default_tree_learner、DecisionTreeRegressor(criterion='friedman_mse', max_depth=4)
    'natural_gradient':True,   # 自然梯度 or 常规梯度
    'n_estimators':1000,  # 迭代次数
    'learning_rate':0.01,  # 学习速率
    'minibatch_frac':1.0,  # 行采样
    'col_sample':1.0,  # 列采样
    'verbose':True,
    'verbose_eval':100,
    'tol':0.0001,   # 迭代过程中损失函数阈值，当损失函数的变化小于tol时，训练过程将停止
    'random_state':1,
}

model = NGBClassifier(**params)
model.fit(X_train, y_train)

y_pred= model.predict(X_test)

# 计算准确率
# print("模型的准确率为:", accuracy_score(y_test, y_pred))

# 计算混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred)
# print(conf_matrix)
# 计算 TPR 和 FPR
TPR = conf_matrix[1, 1] / (conf_matrix[1, 1] + conf_matrix[1, 0])
FPR = conf_matrix[0, 1] / (conf_matrix[0, 1] + conf_matrix[0, 0])
print("模型的True Positive Rate (TPR)为:", TPR)
print("模型的False Positive Rate (FPR)为:", FPR)
print("模型的AUC Score为:", roc_auc_score(y_test, y_pred))
print("模型的F1-Score为:", f1_score(y_test, y_pred))
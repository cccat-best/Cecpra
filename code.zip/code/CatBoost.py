import pandas as pd
from sklearn.metrics import accuracy_score, recall_score, confusion_matrix, roc_auc_score, f1_score
from sklearn.model_selection import train_test_split
import xgboost as xgb
import matplotlib.pyplot as plt

#读文件
df=pd.read_csv('datasets/drop_80/AbsCid_filled_80.csv')
data = df.values

X_train, X_test, y_train, y_test = train_test_split(data[:,5:], data[:,4], test_size=0.2, random_state=42, stratify=data[:,4])

y_train = y_train.astype('int')
y_test = y_test.astype('int')

from catboost import CatBoostClassifier
model = CatBoostClassifier(
    iterations=5,
    learning_rate=0.1,
    loss_function='Logloss'
)
model.fit(
    X_train, y_train,
    verbose=False
)

y_pred= model.predict(X_test)

# 计算准确率
# print("模型的准确率为:", accuracy_score(y_test, y_pred))

# 计算混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred)
# print(conf_matrix)
# 计算 TPR 和 FPR
TPR = conf_matrix[1, 1] / (conf_matrix[1, 1] + conf_matrix[1, 0])
FPR = conf_matrix[0, 1] / (conf_matrix[0, 1] + conf_matrix[0, 0])
print("模型的True Positive Rate (TPR)为:", TPR)
print("模型的False Positive Rate (FPR)为:", FPR)
print("模型的AUC Score为:", roc_auc_score(y_test, y_pred))
print("模型的F1-Score为:", f1_score(y_test, y_pred))

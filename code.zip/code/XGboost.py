import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, recall_score, confusion_matrix, roc_auc_score, f1_score
from sklearn.model_selection import train_test_split
import xgboost as xgb
import matplotlib.pyplot as plt
import os

myDataPath = 'datasets/drop_80/filled_drop_data_80.csv'
myDataName = os.path.basename(myDataPath)
print('模型：XGboost')
print('数据集：', myDataName)
print('训练集：self')

data = pd.read_csv(myDataPath)
data = data.values

X_train, X_test, y_train, y_test = train_test_split(data[:,5:], data[:,4], test_size=0.2, random_state=42, stratify=data[:,4])

y_train = y_train.astype('int')
y_test = y_test.astype('int')

# 计算正负样本的权重比例
negative_samples = np.sum(data[:, 4] == 0)
positive_samples = np.sum(data[:, 4] == 1)
scale_pos_weight = negative_samples / positive_samples

# xgboost模型初始化设置
dtrain=xgb.DMatrix(X_train,label=y_train)
dtest=xgb.DMatrix(X_test)
watchlist = [(dtrain,'train')]

# booster:
params = {
    'booster': 'gbtree',
    'objective': 'binary:logistic',
    'eval_metric': 'aucpr',
    'gamma': 0.2,
    'max_depth': 8,
    'alpha': 0,
    'lambda': 0,
    'subsample': 0.7,
    'colsample_bytree': 0.7,
    'min_child_weight': 3,
    'eta': 0.03,
    'nthread': -1,
    'seed': 2019,
    'scale_pos_weight': scale_pos_weight
}
# 建模与预测：50棵树
bst=xgb.train(params,dtrain,num_boost_round=50,evals=watchlist)
ypred=bst.predict(dtest)


# 设置阈值、评价指标
y_pred = (ypred >= 0.5)*1

# 计算混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred)
# print(conf_matrix)
# 计算 TPR 和 FPR
TPR = conf_matrix[1, 1] / (conf_matrix[1, 1] + conf_matrix[1, 0])
FPR = conf_matrix[0, 1] / (conf_matrix[0, 1] + conf_matrix[0, 0])
print("模型的True Positive Rate (TPR)为:", recall_score(y_test,y_pred))
print("模型的False Positive Rate (FPR)为:", FPR)
print ("模型的AUC Score为:", roc_auc_score(y_test,y_pred))
print ("模型的F1-Score为:", f1_score(y_test,y_pred))



import pandas as pd
import numpy as np
import pickle
from random import shuffle
import lightgbm as LGB
from sklearn.metrics import accuracy_score, recall_score, confusion_matrix, roc_auc_score, f1_score
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import os

myDataPath = 'datasets/cid_Dropna_data.csv'
myDataName = os.path.basename(myDataPath)
print('模型：LightGBM')
print('数据集：', myDataName)
print('训练集：self')

data = pd.read_csv(myDataPath)
data = data.values

x_train, x_test, y_train, y_test = train_test_split(data[:,5:], data[:,4], test_size=0.2, random_state=1, stratify=data[:,4])

y_train = y_train.astype('int')
y_test = y_test.astype('int')

# LGB模型
# 定义 LightGBM 模型参数
params = {
    'objective': 'binary',  # 指定损失函数为二元交叉熵
    'metric': 'binary_error',  # 指定评估指标为二分类错误率
    'max_depth': 20,
    'num_leaves': 100,
    'n_estimators': 600,
    'learning_rate': 0.05,
    'verbosity': -1,
    'random_state':1,
    'class_weight':'balanced'
}
# 训练模型并设置类别权重
lgb = LGB.LGBMClassifier(**params)
# lgb.fit(x_train, y_train) #训练
# #
# with open('pkl/part_mean_cid_Dropna_data_LGB.pkl','wb') as f:
#     pickle.dump(lgb,f)
#     print('dump success')

# 加载模型
with open('pkl/part_mean_cid_Dropna_data_LGB.pkl','rb') as f:
    lgb = pickle.load(f)

print('-------------------------------------------------------------------')

y_pred = lgb.predict(x_test) # 测试

# 计算准确率
# print("模型的准确率为:", accuracy_score(y_test, y_pred))

# 计算混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred)
print(conf_matrix)
# 计算 TPR 和 FPR
TPR = conf_matrix[1, 1] / (conf_matrix[1, 1] + conf_matrix[1, 0])
FPR = conf_matrix[0, 1] / (conf_matrix[0, 1] + conf_matrix[0, 0])
print("模型的True Positive Rate (TPR)为:", TPR)
print("模型的False Positive Rate (FPR)为:", FPR)
print("模型的AUC Score为:", roc_auc_score(y_test, y_pred))
print("模型的F1-Score为:", f1_score(y_test, y_pred))


